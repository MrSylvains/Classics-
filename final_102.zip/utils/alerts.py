# utils/alerts.py
def send_alert(message):
    print("ALERT:", message)
